package TokopediaUtsNaufalNajmuddin;

import java.util.ArrayList;
import java.util.Scanner;

public class tokopediaArray {
    public static void main(String[] args) {
        ArrayList<tokopedia> MasukanBarang = new ArrayList<tokopedia>();
        for (int index = 0; index < 3; index++) {
            tokopedia Barang = new tokopedia();
            Scanner detailInput = new Scanner(System.in);
            System.out.println("Masukkan Nama Barang :");
            Barang.namaBarang = detailInput.nextLine();

            System.out.println("Masukkan Harga:");
            Barang.Harga= detailInput.nextInt();

            System.out.println("Masukkan Katagori Barang : ");
            Barang.Katagori = detailInput.nextLine();

            System.out.println("Masukkan Deskripsi : ");
            Barang.Deskripsi = detailInput.nextLine();

            System.out.println("Masukkan Fotobarang: ");
            Barang.Fotobarang = detailInput.nextLine();

            MasukanBarang.add(Barang);
        }

        for (int i = 0; i < MasukanBarang.size(); i++) {
            String Namabarang = MasukanBarang.get(i).namaBarang;
            int Harga = MasukanBarang.get(i).Harga;
            String Katagori = MasukanBarang.get(i).Katagori;
            String Deskripsi = MasukanBarang.get(i).Deskripsi;
            String Fotobarang = MasukanBarang.get(i).Fotobarang;

            System.out.println("Kartu yang ke " + (i + 1));
            System.out.println("Nomor Kartu     : " + Namabarang);
            System.out.println("Nomor Rekening  : " + Harga);
            System.out.println("Nama Bank       : " + Katagori);
            System.out.println("Nama            : " + Deskripsi);

        }
    }

}
