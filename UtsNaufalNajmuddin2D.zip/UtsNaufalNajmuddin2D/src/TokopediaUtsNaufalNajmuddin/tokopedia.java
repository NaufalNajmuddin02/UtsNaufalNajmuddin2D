package TokopediaUtsNaufalNajmuddin;

public class tokopedia {
    public String namaBarang ;
    public int  Harga;
    public String Katagori ;
    public String Deskripsi ;
    public String Fotobarang;

    public tokopedia(){

    }

    public tokopedia(String nBarang, int Hrg, String Ktgr, String Dskrip, String Fotob){
        this.namaBarang = nBarang;
        this.Harga = Hrg;
        this.Katagori = Ktgr;
        this.Deskripsi = Dskrip;
        this.Fotobarang = Fotob;
    }
    public String getnamabarang(){
        return this.namaBarang;
    }
    public void setnamabarang(String namaBarang){
        this.namaBarang = namaBarang;
    }
    public int getHarga(){
        return this.Harga;
    }
    public void setHarga(int Harga){
        this.Harga = Harga;
    }
    public String getKatagori(){
        return this.Katagori;
    }
    public void setKatagori(String Katagori){
        this.Katagori = Katagori;
    }
    public String getDeskripsi(){
        return this.Deskripsi;
    }
    public void setDeskripsi(String Deskripsi){
        this.Deskripsi = Deskripsi;
    }
    public String getFotobang(){
        return this.Fotobarang;
    }
    public void setFotobarang(String Fotobarang){
        this.Fotobarang = Fotobarang;
    }
}
